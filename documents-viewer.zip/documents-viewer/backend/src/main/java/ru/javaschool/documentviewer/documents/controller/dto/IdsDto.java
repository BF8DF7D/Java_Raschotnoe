package ru.javaschool.documentviewer.documents.controller.dto;

import lombok.Data;

import java.util.Set;

@Data
public class IdsDto {

    private Set<Long> ids;

}
