package ru.javaschool.documentviewer.documents.controller.dto;

import lombok.Data;

@Data
public class IdDto {
    private Long id;
}
