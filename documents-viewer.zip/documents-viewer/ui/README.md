# Фронт

## Зависимости
См. package.json

## Запуск
1) npm install
2) npm start

Фронт поднимется на порту 9000
http://localhost:9000/#/
